<!-- category menu start -->
                    <div class="col-xl-3">
                        <div class="category-dropdown-wrapper">
                            <div class="category-toggle-wrap">
                                <div class="category-toggle category-toggle-style_3">
                                    <i class="ion-android-menu"></i>
                                    Categorias
                                </div>
                                <nav class="category-menu category-menu-style_3">
                                    <ul class="categories-list categories-list-style_3">
                                        <li class="menu-item-has-children"><a href="shop.php">Torneiras</a>
                                            <!-- Mega Category Menu Start -->
                                            <ul class="category-mega-menu dropdown">
                                                <li class="menu-item-has-children">
                                                    <a href="shop.php">Torneiras Automáticas</a>
                                                    <ul class="dropdown">
                                                        <li><a href="shop.php">Torneiras Automáticas</a></li>
                                                        <li><a href="shop.php">Torneira Temporizada</a></li>
                                                    </ul>
                                                </li>
                                                <li class="menu-item-has-children">
                                                    <a href="shop.php">Torneiras para Clínicas</a>
                                                    <ul class="dropdown">
                                                        <li><a href="shop.php">Torneira clínica</a></li>
                                                        <li><a href="shop.php">Torneira clínica com misturador</a></li>
                                            
                                                    </ul>
                                                </li>
                                                <li class="menu-item-has-children">
                                                    <a href="shop.php">Torneiras com Sensor</a>
                                                    <ul class="dropdown">
                                                        <li><a href="shop.php">Torneira com Sensor de Mesa</a></li>
                                                        <li><a href="shop.php">Torneira com Sensor de Parede</a></li>
                                                        
                                                    </ul>
                                                </li>
                                                <li class="menu-item-has-children">
                                                    <a href="shop.php">Torneiras de Pedal</a>
                                                    <ul class="dropdown">
                                                        <li><a href="shop.php">Torneira de Pedal Mecânico</a></li>
                                                        <li><a href="shop.php">Torneira de Pedal Elétrico</a></li>
                                                    
                                                    </ul>
                                                </li>
                                            </ul><!-- Mega Category Menu End -->
                                        </li>
                                        <li class="menu-item-has-children"><a href="shop.php">Saboneteiras</a>
                                            <!-- Mega Category Menu Start -->
                                            <ul class="category-mega-menu dropdown three-column">
                                                <li class="menu-item-has-children">
                                                    <a href="shop.php">Smartphone</a>
                                                    <ul class="dropdown">
                                                        <li><a href="shop.php">Samsome</a></li>
                                                        <li><a href="shop.php">GL Stylus</a></li>
                                                        <li><a href="shop.php">Uawei</a></li>
                                                        <li><a href="shop.php">Cherry Berry</a></li>
                                                        <li><a href="shop.php">uPhone</a></li>
                                                    </ul>
                                                </li>
                                                <li class="menu-item-has-children">
                                                    <a href="shop.php">headphone</a>
                                                    <ul class="dropdown">
                                                        <li><a href="shop.php">Desktop Headphone</a></li>
                                                        <li><a href="shop.php">Mobile Headphone</a></li>
                                                        <li><a href="shop.php">Wireless Headphone</a></li>
                                                        <li><a href="shop.php">LED Headphone</a></li>
                                                        <li><a href="shop.php">Over-ear</a></li>
                                                    </ul>
                                                </li>
                                                <li class="menu-item-has-children">
                                                    <a href="shop.php">accessories</a>
                                                    <ul class="dropdown">
                                                        <li><a href="shop.php">Power Bank</a></li>
                                                        <li><a href="shop.php">Data Cable</a></li>
                                                        <li><a href="shop.php">Power Cable</a></li>
                                                        <li><a href="shop.php">Battery</a></li>
                                                        <li><a href="shop.php">OTG Cable</a></li>
                                                    </ul>
                                                </li>
                                            </ul><!-- Mega Category Menu End -->
                                        </li>
                                        <li class="menu-item-has-children"><a href="shop.php">Acessibilidade</a>
                                            <!-- Mega Category Menu Start -->
                                            <ul class="category-mega-menu dropdown two-column">
                                                <li class="menu-item-has-children">
                                                    <a href="shop.php">Smartphone</a>
                                                    <ul class="dropdown">
                                                        <li><a href="shop.php">Samsome</a></li>
                                                        <li><a href="shop.php">GL Stylus</a></li>
                                                        <li><a href="shop.php">Uawei</a></li>
                                                        <li><a href="shop.php">Cherry Berry</a></li>
                                                    </ul>
                                                </li>
                                            </ul><!-- Mega Category Menu End -->
                                        </li>
                                        <li><a href="shop.php">Trocador de Fraldas</a></li>
                                        <li><a href="shop.php">Torneiras para Cozinha Industrial</a></li>
                                        <!--<li><a href="shop.php">Frozen</a></li>
                                        <li><a href="shop.php">Grocery</a></li>
                                        <li><a href="shop.php">Kitchenware</a></li>
                                        <li><a href="shop.php">Tools</a></li>
                                        <li><a href="shop.php">Electronics</a></li>
                                        <li><a href="shop.php">Kitchenware</a></li>
                                        <li><a href="shop.php">Tools</a></li>
                                        <li><a href="shop.php">Electronics</a></li>-->
                                    </ul>
                                </nav>
                            </div>
                        </div>
                    </div>
                    <!-- category menu start -->