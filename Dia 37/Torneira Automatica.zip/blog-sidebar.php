<div class="col-lg-3 order-2">
                        <div class="blog-sidebar-wrapper">
                            <div class="blog-sidebar">
                                <h4 class="title">Pesquisar</h4>
                                <div class="sidebar-serch-form">
                                    <form action="#">
                                        <input type="text" class="search-field" placeholder="">
                                        <button type="submit" class="search-btn"><i class="fa fa-search"></i></button>
                                    </form>
                                </div>
                            </div> <!-- single sidebar end -->
                            <div class="blog-sidebar">
                                <h4 class="title">Categorias</h4>
                                <ul class="blog-archive blog-category">
                                    <li><a href="#">Barber (10)</a></li>
                                    <li><a href="#">fashion (08)</a></li>
                                    <li><a href="#">handbag (07)</a></li>
                                    <li><a href="#">Jewelry (14)</a></li>
                                    <li><a href="#">food (10)</a></li>
                                </ul>
                            </div> <!-- single sidebar end -->
                            
                            <div class="blog-sidebar">
                                <h4 class="title">Recentes</h4>
                                <div class="recent-post">
                                    <div class="recent-post-item">
                                        <div class="product-thumb">
                                            <a href="blog-details.html">
                                                <img src="assets/img/blog/blog-large-4.jpg" alt="">
                                            </a>
                                        </div>
                                        <div class="recent-post-description">
                                            <div class="product-name">
                                                <h4><a href="blog-details.html">Auctor gravida enim</a></h4>
                                                <p>mar 10 2021</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="recent-post-item">
                                        <div class="product-thumb">
                                            <a href="blog-details.html">
                                                <img src="assets/img/blog/blog-large-6.jpg" alt="">
                                            </a>
                                        </div>
                                        <div class="recent-post-description">
                                            <div class="product-name">
                                                <h4><a href="blog-details.html">gravida auctor dnim</a></h4>
                                                <p>mar 18 2021</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="recent-post-item">
                                        <div class="product-thumb">
                                            <a href="blog-details.html">
                                                <img src="assets/img/blog/blog-large-7.jpg" alt="">
                                            </a>
                                        </div>
                                        <div class="recent-post-description">
                                            <div class="product-name">
                                                <h4><a href="blog-details.html">enim auctor gravida</a></h4>
                                                <p>march 14 2021</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div> <!-- single sidebar end -->
                            <div class="blog-sidebar">
                                <h4 class="title">Tags</h4>
                                <ul class="blog-tags">
                                    <li><a href="#">camera</a></li>
                                    <li><a href="#">computer</a></li>
                                    <li><a href="#">bag</a></li>
                                    <li><a href="#">watch</a></li>
                                    <li><a href="#">smartphone</a></li>
                                    <li><a href="#">shoes</a></li>
                                </ul>
                            </div> <!-- single sidebar end -->
                        </div>
                    </div>